package com.portfolio.ferco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FercoApplicationTests {

	@Test
	void contextLoads() {
	}

}
