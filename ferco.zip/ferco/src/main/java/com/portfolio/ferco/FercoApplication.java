package com.portfolio.ferco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FercoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FercoApplication.class, args);
	}

}
